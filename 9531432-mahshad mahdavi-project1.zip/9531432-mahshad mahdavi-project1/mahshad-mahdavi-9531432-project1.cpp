#include <iostream>
#include <cstddef>
#include <stdio.h>
#include <ctime>
#include <string.h>
#include <windows.h> 
using namespace std;
int count=0;
int f;
class Gnode{
	public: int tag;
	public: int ref;
	public: Gnode *link;
	Gnode *dlink;
	char service;
	Gnode(){
		service='f';
		tag=0;
		ref=0;
		link=0;
		dlink=0;
	}
	public: Gnode* addservice(char servicename,Gnode *first){
			Gnode *l=new Gnode();
			if(count==0){
				l->service=servicename;
				first=l;
			}
			else{
				Gnode *q=new Gnode();
				q=first;
				while(q->link){
					q=q->link;
				}
				l->service=servicename;
				q->link=l;
			}
			count++;
			return first;
	}
	public:	Gnode* addsubservice(char name1,char name2,Gnode *first){
		Gnode *y=first;Gnode *bx[100];for(int o=0;o<100;o++) bx[o]=new Gnode();int len=0;
		int sign[100];
		for(int o=0;o<100;o++) sign[o]=0;
		Gnode *tr=search(name1,y,bx,len,sign);
		if(tr!=0){
		Gnode *s=new Gnode();
		s->tag=0;
		s->ref=0;
		s->service=name2;
		s->link=0;
		if(tr->dlink==NULL)
			tr->dlink=s;
		else{
		Gnode *f=tr->dlink;
		while(f->link)
		f=f->link;
		f->link=s;
		}
		return first;
	}
	else cout<<"voko";
	}
	public:	Gnode* search(char n1,Gnode *first,Gnode *bx[100],int len,int sign[100]){
		//cout<<"kk"<<first->service;
		if(first->service==n1){
		return first;}
		else{
			Gnode *x=first;
			Gnode *l=x->link;
			Gnode *r=x->dlink;
			if(l!=0 && r!=0){
			
			//cout<<"l :"<<l->service<<"\n";
			//cout<<"r:  "<<r->service<<"\n";
			}
			if(r==0 && l!=0){
				//cout<<"search1("<<n1<<l->service<<"\n";
				search(n1,l,bx,len,sign);
			}
			if(r!=0 && l==0){
				//cout<<"search2("<<n1<<r->service<<"\n";
				search(n1,r,bx,len,sign);
			}
			if(r!=0 && l!=0){
				bx[len++]=l;
				//cout<<"bzar to saf "<<l->service<<"\n";
				//cout<<"search3("<<n1<<r->service<<"\n";
				search(n1,r,bx,len,sign);
			}
			if(r==0 && l==0){
				Gnode *temp=new Gnode();
				for(int cnt=len-1;cnt>=0;cnt--){
					if(sign[cnt]==0){
						temp=bx[cnt];
						//cout<<"l:  "<<temp->service<<"\n";
						sign[cnt]=1;
						break;
					}
				}
			search(n1,temp,bx,len,sign);	
			}
		}
		
	 
}
	public:	void listservices(Gnode *first){
		print(first);
	}
	void print(Gnode *z){
		Gnode *x=new Gnode();
		x=z;
		if(x){
			if(x->tag==0){
				cout<<x->service<<"   ";
				if(x->dlink){
				Gnode *y=new Gnode();
				y=x->dlink;
				print(y);x=x->link;print(x);
				}
				else{
				x=x->link;
					print(x);
				}
			}
		}
		else
		return;
	}
	public: void list_from(char service,Gnode *first){
		Gnode *y=first;Gnode *bx[100];for(int o=0;o<100;o++) bx[o]=new Gnode();int len=0;
		int sign[100];
		for(int o=0;o<100;o++) sign[o]=0;
		Gnode *tr=search(service,y,bx,len,sign);
		tr=tr->dlink;
		listservices(tr);
	}
};
int count2=0;int c=0;
class Anode{
	public:char agencyname;
	public:Gnode *o=new Gnode();
	public:Gnode* Array[100];
	public:Anode* link;
	Anode(){
		agencyname='f';
		for(int i=0;i<99;i++){
			Array[i]=0;
			
		}
		link=0;
		
	}
	Anode*	addagency(char agencyna,Anode *first2){
	Anode *o1=new Anode();
	if(count2==0){
		first2=o1;
		o1->agencyname=agencyna;
		for(int i=0;i<99;i++){
		
		o1->Array[i]=0;}
		o1->link=0;
	}
	else{
		Anode *o2=first2;
		while(o2->link){
			o2=o2->link;
		}
		o2->link=o1;
		o1->agencyname=agencyna;
		
		for(int i=0;i<99;i++){
		o1->Array[i]=0;}
		o1->link=0;}
		count2++;
		return first2;
	}
	Anode*	addoffer(char servicenamet,char agencynamet,Anode *first2,Gnode *f1){
	Gnode *t5=new Gnode();
	Anode *z;
	z=first2;
	t5=f1;
	while(z->agencyname!=agencynamet){
		z=z->link;
	}
	while(t5->service!=servicenamet){
		if(t5->service==servicenamet){
		break;
	}
		t5=t5->link;
	}	
	z->Array[c]=t5;
	t5->ref++;
	c++;
	return first2;	
	}
	void listagencies(Anode *first){
		Anode *tt=first;
		while(tt!=0){
			cout<<tt->agencyname;
			tt=tt->link;
		}
	}
	Gnode* delete8(char servise,char agency,Anode *firsta,Gnode *firstg){
	Gnode *gg=new Gnode();
	Anode *aa=new Anode();
	aa=firsta;
	while(aa->agencyname !=agency && aa){
		aa=aa->link;
	}
	if(aa){
		for(int i=0;i<99 ;i++){
			if(aa->Array[i]->service==servise){
					gg=aa->Array[i];
					aa->Array[i]=0;
				break;
			}
		}}
		gg->ref=gg->ref -1;
		//cout<<gg->ref;
		if(gg->ref==0){
			Gnode *qq=new Gnode();
			qq=	delete11(gg,firstg);
			//cout<<qq->link->link->service;
			return qq;
			
		}
	}
Gnode*	delete11(Gnode *k,Gnode *first1){
	Gnode *first=new Gnode();
	first=first1;
	if(first==k){
		if(k->dlink!=0){
			k->dlink=0;
			first=first->link;
			k->link=0;
			return first;
		}
		else{
			first=first->link;
			k->link=0;
		}
	}
	else{
		while(first->link!=k){
				first=first->link;
			}
			if(k->link!=0){
				first->link=k->link;
			//	k=NULL;
			}
			if(k->link==0){
				first->link=0;
			//	k=NULL;
			
			}
	}
	return first1;
}
/////////////////////////////


///////////////////////////////
};
class Mnode{
	public: char service;
	public: char agency;
	public:long double  time;
	public: int priority;
	public: Mnode(){
		agency='f';
		service='f';
		time=0;
		priority=10;
	}
	
void max_heapify(Mnode a[], int i, int n){
	//////////////
	Mnode temp;int j;
	Mnode w;
	temp=a[i];
    j = 2 * i;
    while (j <= n)
    {
    	//cout<<"n:  "<<n<<"    "<<temp.priority<<"   "<<a[j].priority<<"\n";
        if (j < n && a[j+1].priority > a[j].priority||(a[j+1].priority == a[j].priority && a[j+1].time < a[j].time)){
        	//cout<<"manam1\n";
            j = j + 1;
            }
        if (temp.priority>a[j].priority||(temp.priority==a[j].priority && temp.time<a[j].time)){
        	//cout<<"manam2\n";
            break;}
        else
        if(temp.priority<a[j].priority||(temp.priority==a[i].priority && temp.time>a[j].time)  )
        {
        	//cout<<"manam3\n";
            a[j / 2] = a[j];
            j = 2 * j;
        }
    	
    }
    a[j/2] = temp;
    if(i==1){
    	int ii=1;
 }
}
void build_maxheap(Mnode a[],int n){
    int i;
    for(i = n/2; i >= 1; i--)
    {	
        max_heapify(a,i,n);
    }
}};

Gnode*q;
Gnode*first;
Gnode*r;
	Anode *first2;int x_prev=0;
	int main(){
	int cnt=0;int x=0;
	Gnode *t=new Gnode();first=NULL;Anode *t7=new Anode();first2=NULL;HANDLE  hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	 int bsx=0;Mnode a[20];int nn=1;
	while(cnt<=100){
	SetConsoleTextAttribute(hConsole, 3);
	cout<<"what do you want?\n";
	cout<<"Add Service (0)\n";cout<<"Add Sub Service (1)\n";cout<<"Add Agency (2)\n";cout<<"Add Offer (3)\n";cout<<"Delete (4)\n";
	cout<<"List Service (5)\n";cout<<"List Agecy (6)\n";cout<<"List Service From (7)\n";cout<<"Add Order (8)\n";cout<<"List Orders (9)\n";cout<<"Delete Orders (10)\n";
    SetConsoleTextAttribute(hConsole, 15);
	cin>>x;
	if(x==0){
	cout<<"enter your service\n";
	char service;
	cin >> service;
	first=t->addservice(service,first);
	}
	if(x==1){
	cout<<"enter your service you want to add sub service\n";
	char service;
	cin >> service;
	cout<<"enter your sub service\n";
	char sub_service;
	cin >> sub_service;
	first=t->addsubservice(service,sub_service,first);
	}
	if(x==2){
	cout<<"enter agency you want to add\n";
	char agancy;
	cin >> agancy;
	first2=t7->addagency(agancy,first2);
	}
	if(x==3){
	cout<<"enter your agency you want to add offer\n";
	char agancy;
	cin >> agancy;
	cout<<"enter your sub service\n";
	char offer;
	cin >> offer;
	first2=t7->addoffer(offer,agancy,first2,first);
	}
	if(x==4){
	cout<<"enter your agency you want to delete offer\n";
	char agancy;
	cin >> agancy;
	cout<<"enter your offer want to deleted\n";
	char offer;
	cin >> offer;
	first=t7->delete8(offer,agancy,first2,first);
	}
	if(x==5){
		t->listservices(first);cout<<"\n";
	}
	if(x==6){
		t7->listagencies(first2);cout<<"\n";
	}
	if(x==7){
		cout<<"enter service you want to see sub service\n";
		char service;
		cin>>service;
		t->list_from(service,first);cout<<"\n";
	}
	if(x==8){
	///////////////////////
	int ix=1;
	Mnode *temp=new Mnode();
	while(ix<=20){
  cout<<"enter your service\n";
    cin>>a[ix].service;
    cout<<"enter your agency\n";
    cin>>a[ix].agency;
    cout<<"enter your priority(0,1,2)\n";
    cin>>a[ix].priority;
    const long double sysTime = time(0);
const long double sysTimeMS = sysTime*1000;
	a[ix].time=sysTimeMS;
    char cx;
	cout<<"is any other order(y/n)"<<"/n";
    cin>>cx;
    if(cx=='n')
  break;
   else {
	ix++;nn++;}
}temp->build_maxheap(a,nn);
	///////////////////////
	}
	if(x==9){
	cout<<"Max Heap\n";
    for (int o = 1;o<=nn;o++)
    {
    	if(a[o].agency!=NULL)
        cout<<a[o].service<<"     "<<a[o].agency<<"     "<<a[o].time<<"   :"<<a[o].priority<<endl;
    }
	}
	if(x==10){
			Mnode *temp=new Mnode();
		cout<<"enter agency you want to delete from\n";
		char agency;
		cin>>agency;
		Mnode b[nn-1];int uu=1;
		for(int o=1;o<=nn;o++){
			if(a[o].agency==agency){
				a[o].agency=NULL;
			}
		}
		temp->build_maxheap(b,nn-1);
	}
	char cc;
	cout<<"Do you want to continue? (y/n)\n";
	cin>>cc;
	if(cc=='n')
	break;
	cnt++;
}
	return 0;


}




